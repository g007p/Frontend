var express = require('express');
var PORT = process.env.PORT || 3000;

var app = express();

app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.listen(PORT, () => {
    console.log('Listening on PORT 3000...');
});